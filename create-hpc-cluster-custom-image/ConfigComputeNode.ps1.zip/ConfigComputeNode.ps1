﻿configuration ConfigComputeNode 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=30,

        [String]$PostConfigScript = ""
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $scriptUrl = ""
    $scriptArgs = ""
    if(-not [string]::IsNullOrEmpty($PostConfigScript))
    {
        $postScript = $PostConfigScript.Trim()
        $firstSpace = $postScript.IndexOf(' ')
        if($firstSpace -gt 0)
        {
            $scriptUrl = $postScript.Substring(0, $firstSpace)
            $scriptArgs = $postScript.Substring($firstSpace + 1).Trim()
        }
        else
        {
            $scriptUrl = $postScript
        }
    }
    Write-Verbose -Message "PostConfigScript: url=$scriptUrl, args=$scriptArgs."

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        Script PostConfig
        {
            GetScript = {
                return @{
                    Result = $true
                }
            }
            
            SetScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                $scriptFileName = $($scriptUrl -split '/')[-1]
                $scriptFilePath = "$env:windir\Temp\$scriptFileName"
                Write-Verbose -Message "Download script from $scriptUrl to $scriptFilePath."
                $webclient = New-Object System.Net.WebClient
                $webclient.DownloadFile($scriptUrl,$scriptFilePath)
                $command = "Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope Process -Force; $scriptFileName $scriptArgs"
                Write-Verbose -Message "Execute powershell command: $command."
                Invoke-Expression -Command $command
                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                "done" | Out-File "$env:windir\Temp\$machineId.done"
            }
            
            TestScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                if([string]::IsNullOrEmpty($scriptUrl)) 
                {
                    return $true
                }
                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                Test-Path -Path "$env:windir\Temp\$machineId.done"
            }
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

   }
} 

function Format-PostConfigScriptBlock
{
    param(
        [parameter(Mandatory=$false)]
        [string] $scriptUrl = "",

        [parameter(Mandatory=$false)]
        [string] $scriptArgs = "",

        [parameter(Mandatory=$true)]
        [System.Management.Automation.ScriptBlock] $scriptBlock

    )

    $result = $scriptBlock.ToString()
    $result = $result.Replace("{ScriptUrlPlaceholder}", $scriptUrl)
    $result = $result.Replace("{ScriptArgsPlaceholder}", $scriptArgs)
    return $result
}