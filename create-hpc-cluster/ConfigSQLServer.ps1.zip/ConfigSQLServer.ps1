﻿configuration ConfigSQLServer 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [String]$SQLInstanceName = "MSSQLSERVER",

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xSQLServer, xComputerManagement
    $ADUserName = "${DomainName}\$($Admincreds.UserName)"
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ($ADUserName, $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            FSLabel = 'ADData'
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        Group AddADUserToLocalAdminGroup
        {
            GroupName = 'Administrators'   
            Ensure = 'Present'             
            MembersToInclude= $ADUserName
            Credential = $DomainCreds    
            DependsOn = "[xComputer]DomainJoin"
        }

        xSQLServerLogin AddSQLServerLogin
        {
            Ensure = "Present"
            Name = $ADUserName
            LoginType = "WindowsUser"
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[xComputer]DomainJoin"
        }

        File HPCDataFolder
        {
            Type = 'Directory'
            Ensure = "Present"
            DestinationPath = 'F:\HPCData'
        }

        cSQLServerDatabase HPCManagementDB
        {
            Database = 'HPCManagement'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCSchedulerDB
        {
            Database = 'HPCScheduler'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 50
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCReportingDB
        {
            Database = 'HPCReporting'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCDiagnosticsDB
        {
            Database = 'HPCDiagnostics'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 256
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCMonitoringDB
        {
            Database = 'HPCMonitoring'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 512
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        xSQLServerDatabaseOwner HPCManagementDBOwner
        {
            Name = $ADUserName
            Database = 'HPCManagement'
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[cSQLServerDatabase]HPCManagementDB"
        }

        xSQLServerDatabaseOwner HPCSchedulerDBOwner
        {
            Name = $ADUserName
            Database = 'HPCScheduler'
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[cSQLServerDatabase]HPCSchedulerDB"
        }

        xSQLServerDatabaseOwner HPCReportingDBOwner
        {
            Name = $ADUserName
            Database = 'HPCReporting'
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[cSQLServerDatabase]HPCReportingDB"
        }

        xSQLServerDatabaseOwner HPCDiagnosticsDBOwner
        {
            Name = $ADUserName
            Database = 'HPCDiagnostics'
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[cSQLServerDatabase]HPCDiagnosticsDB"
        }

        xSQLServerDatabaseOwner HPCMonitoringDBOwner
        {
            Name = $ADUserName
            Database = 'HPCMonitoring'
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[cSQLServerDatabase]HPCMonitoringDB"
        }
   }
} 

