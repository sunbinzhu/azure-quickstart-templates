﻿configuration ConfigComputeNode 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=30,

        [String]$PostConfigScript = ""
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $scriptUrl = ""
    $scriptArgs = ""
    if(-not [string]::IsNullOrEmpty($PostConfigScript))
    {
        $scriptUrl = $PostConfigScript.Trim()
        $firstSpace = $scriptUrl.IndexOf(' ')
        if($firstSpace -gt 0)
        {
            $scriptUrl = $scriptUrl.Substring(0, $firstSpace)
            $scriptArgs = $scriptUrl.Substring($firstSpace + 1).Trim()
        }
    }

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        Script PostConfig
        {
            GetScript = {
                return @{
                    Result = $true
                }
            }
            
            SetScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if([string]::IsNullOrEmpty($scriptUrl))
                {
                    "No custom script specified" | Out-File "$env:windir\Temp\$machineId.done"
                    return
                }

                if(-not [system.uri]::IsWellFormedUriString($scriptUrl,[System.UriKind]::Absolute) -or $scriptUrl -notmatch '.ps1$')
                {
                    throw  "Invalid url or not PowerShell script: $scriptUrl"
                }

                $scriptFileName = $($scriptUrl -split '/')[-1]
                $scriptFilePath = "$env:windir\Temp\$scriptFileName"
                Write-Verbose -Message "Download script from $scriptUrl to $scriptFilePath."
                $downloader = New-Object System.Net.WebClient
                $downloadRetry = 0
                $downloaded = $false
                while($true)
                {
                    try
                    {
                        $downloader.DownloadFile($scriptUrl, $scriptFilePath)
                        $downloaded = $true
                        break
                    }
                    catch
                    {
                        if($downloadRetry -lt 10)
                        {
                            Write-Verbose -Message  ("Failed to download $scriptUrl, retry after 20 seconds:" + $_)
                            Clear-DnsClientCache
                            Start-Sleep -Seconds 20
                            $downloadRetry++
                        }
                        else
                        {
                            throw "Failed to download $scriptUrl after 10 retries"
                        }
                    }
                }

                $pobj = Invoke-WmiMethod -Path win32_process -Name Create -ArgumentList "PowerShell.exe -ExecutionPolicy Unrestricted -File $scriptFilePath $scriptArgs"
                if($pobj.ReturnValue -eq 0)
                {
                    Write-Verbose -Message "Start to run: $scriptFilePath $scriptArgs."
                    "Started: $scriptFilePath $scriptArgs" | Out-File "$env:windir\Temp\$machineId.done"
                }
                else
                {
                    throw "Failed to start script: $scriptFilePath $scriptArgs."
                }
            }
            
            TestScript = {
                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                Test-Path -Path "$env:windir\Temp\$machineId.result"
            }

            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

   }
} 

function Format-PostConfigScriptBlock
{
    param(
        [parameter(Mandatory=$false)]
        [string] $scriptUrl = "",

        [parameter(Mandatory=$false)]
        [string] $scriptArgs = "",

        [parameter(Mandatory=$true)]
        [System.Management.Automation.ScriptBlock] $scriptBlock

    )

    $result = $scriptBlock.ToString()
    $result = $result.Replace("{ScriptUrlPlaceholder}", $scriptUrl)
    $result = $result.Replace("{ScriptArgsPlaceholder}", $scriptArgs)
    return $result
}