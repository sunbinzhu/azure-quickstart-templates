﻿configuration ConfigComputeNode 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=30,
        [Int]$RetryIntervalSec=30,

        [String]$PostConfigScript = ""
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $scriptUrl = ""
    $scriptArgs = ""
    if(-not [string]::IsNullOrEmpty($PostConfigScript))
    {
        $PostConfigScript = $PostConfigScript.Trim()
        $firstSpace = $PostConfigScript.IndexOf(' ')
        if($firstSpace -gt 0)
        {
            $scriptUrl = $PostConfigScript.Substring(0, $firstSpace)
            $scriptArgs = $PostConfigScript.Substring($firstSpace + 1).Trim()
        }
        else
        {
            $scriptUrl = $PostConfigScript
        }
    }

    $passwd = $Admincreds.GetNetworkCredential().Password

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        Script PostConfig
        {
            GetScript = {
                return @{
                    Result = $true
                }
            }
            
            SetScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -UserName $DomainCreds.UserName -Password $passwd -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                $userName = @"
{UserNamePlaceholder}
"@
                $passwd = @"
{PasswordPlaceholder}
"@
                $userCred = New-Object -TypeName System.Management.Automation.PSCredential `
                        -ArgumentList @($userName, (ConvertTo-SecureString -String $passwd -AsPlainText -Force))
                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if([string]::IsNullOrEmpty($scriptUrl))
                {
                    "$scriptUrl $scriptArgs" | Out-File "$env:windir\Temp\$machineId.done"
                    "No custom script specified" | Out-File "$env:windir\Temp\$machineId.done" -Append
                    return
                }

                if(-not [system.uri]::IsWellFormedUriString($scriptUrl,[System.UriKind]::Absolute) -or $scriptUrl -notmatch '.ps1$')
                {
                    throw  "Invalid url or not PowerShell script: $scriptUrl"
                }

                $scriptFileName = $($scriptUrl -split '/')[-1]
                $scriptFilePath = "$env:windir\Temp\$scriptFileName"
                Write-Verbose -Message "Download script from $scriptUrl to $scriptFilePath."
                $downloader = New-Object System.Net.WebClient
                $downloadRetry = 0
                while($true)
                {
                    try
                    {
                        $downloader.DownloadFile($scriptUrl, $scriptFilePath)
                        break
                    }
                    catch
                    {
                        if($downloadRetry -lt 10)
                        {
                            Write-Verbose -Message  ("Failed to download $scriptUrl, retry after 20 seconds:" + $_)
                            Clear-DnsClientCache
                            Start-Sleep -Seconds 20
                            $downloadRetry++
                        }
                        else
                        {
                            throw "Failed to download $scriptUrl after 10 retries"
                        }
                    }
                }

                # Sometimes the new process failed to run due to system not ready, we add a file creation command to check whether the process works
                $testFileName = "$env:windir\Temp\HPCPostConfigScriptTest."  + (Get-Random)
                $scriptCmd = "'test' | Out-File '$testFileName'; $scriptFilePath $scriptArgs -Under User"
                $encodedCmd = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($scriptCmd))
                $scriptRetry = 0
                while($true)
                {
                    $pobj = Invoke-WmiMethod -Path win32_process -Name Create -ArgumentList "PowerShell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand $encodedCmd" -Impersonation 3 -EnableAllPrivileges -Credential $userCred
                    if($pobj.ReturnValue -eq 0)
                    {
                        Start-Sleep -Seconds 5
                        if(Test-Path -Path $testFileName)
                        {
                            Remove-Item -Path $testFileName -Force -ErrorAction Continue
                            Write-Verbose -Message "Started to run: $scriptFilePath $scriptArgs."
                            "$scriptUrl $scriptArgs" | Out-File "$env:windir\Temp\$machineId.done"
                            "Started $scriptRetry : $scriptFilePath $scriptArgs" | Out-File "$env:windir\Temp\$machineId.done" -Append
                            break
                        }
                        else
                        {
                            Write-Verbose -Message "The new process failed to run, stop it."
                            Stop-Process -Id $pobj.ProcessId
                        }
                    }
                    else
                    {
                        Write-Verbose -Message "Failed to start process: $scriptFilePath $scriptArgs."
                    }

                    if($scriptRetry -lt 10)
                    {
                        $scriptRetry++
                        Start-Sleep -Seconds 10
                    }
                    else
                    {
                        throw "Failed to run post configuration script: $scriptFilePath $scriptArgs."
                    }
                }
            }
            
            TestScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                if([string]::IsNullOrEmpty($scriptUrl))
                {
                    return $true
                }

                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if(Test-Path -Path "$env:windir\Temp\$machineId.done")
                {
                    $lines = @(Get-Content "$env:windir\Temp\$machineId.done")
                    return $lines[0] -eq "$scriptUrl $scriptArgs"
                }
                return $false
            }

            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

        Script PostConfigLocal
        {
            GetScript = {
                return @{
                    Result = $true
                }
            }
            
            SetScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -UserName $DomainCreds.UserName -Password $passwd -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                $userName = @"
{UserNamePlaceholder}
"@
                $passwd = @"
{PasswordPlaceholder}
"@
                $userCred = New-Object -TypeName System.Management.Automation.PSCredential `
                        -ArgumentList @($userName, (ConvertTo-SecureString -String $passwd -AsPlainText -Force))

                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if([string]::IsNullOrEmpty($scriptUrl))
                {
                    "$scriptUrl $scriptArgs" | Out-File "$env:windir\Temp\$machineId.local"
                    "No custom script specified" | Out-File "$env:windir\Temp\$machineId.local" -Append
                    return
                }

                if(-not [system.uri]::IsWellFormedUriString($scriptUrl,[System.UriKind]::Absolute) -or $scriptUrl -notmatch '.ps1$')
                {
                    throw  "Invalid url or not PowerShell script: $scriptUrl"
                }

                $scriptFileName = "local" + $($scriptUrl -split '/')[-1]
                $scriptFilePath = "$env:windir\Temp\$scriptFileName"
                Write-Verbose -Message "Download script from $scriptUrl to $scriptFilePath."
                $downloader = New-Object System.Net.WebClient
                $downloadRetry = 0
                while($true)
                {
                    try
                    {
                        $downloader.DownloadFile($scriptUrl, $scriptFilePath)
                        break
                    }
                    catch
                    {
                        if($downloadRetry -lt 10)
                        {
                            Write-Verbose -Message  ("Failed to download $scriptUrl, retry after 20 seconds:" + $_)
                            Clear-DnsClientCache
                            Start-Sleep -Seconds 20
                            $downloadRetry++
                        }
                        else
                        {
                            throw "Failed to download $scriptUrl after 10 retries"
                        }
                    }
                }

                # Sometimes the new process failed to run due to system not ready, we add a file creation command to check whether the process works
                $testFileName = "$env:windir\Temp\HPCPostConfigScriptTest."  + (Get-Random)
                $scriptCmd = "'test' | Out-File '$testFileName'; $scriptFilePath $scriptArgs -Under Local"
                $encodedCmd = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($scriptCmd))
                $scriptRetry = 0
                while($true)
                {
                    $pobj = Invoke-WmiMethod -Path win32_process -Name Create -ArgumentList "PowerShell.exe -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -EncodedCommand $encodedCmd" -Impersonation 3 -EnableAllPrivileges -Credential $userCred
                    if($pobj.ReturnValue -eq 0)
                    {
                        Start-Sleep -Seconds 5
                        if(Test-Path -Path $testFileName)
                        {
                            Remove-Item -Path $testFileName -Force -ErrorAction Continue
                            Write-Verbose -Message "Started to run: $scriptFilePath $scriptArgs."
                            "$scriptUrl $scriptArgs" | Out-File "$env:windir\Temp\$machineId.local"
                            "Started $scriptRetry : $scriptFilePath $scriptArgs" | Out-File "$env:windir\Temp\$machineId.local" -Append
                            break
                        }
                        else
                        {
                            Write-Verbose -Message "The new process failed to run, stop it."
                            Stop-Process -Id $pobj.ProcessId
                        }
                    }
                    else
                    {
                        Write-Verbose -Message "Failed to start process: $scriptFilePath $scriptArgs."
                    }

                    if($scriptRetry -lt 10)
                    {
                        $scriptRetry++
                        Start-Sleep -Seconds 10
                    }
                    else
                    {
                        throw "Failed to run post configuration script: $scriptFilePath $scriptArgs."
                    }
                }
            }
            
            TestScript = Format-PostConfigScriptBlock -scriptUrl $scriptUrl -scriptArgs $scriptArgs -scriptBlock {
                $scriptUrl = @"
{ScriptUrlPlaceholder}
"@
                $scriptArgs = @"
{ScriptArgsPlaceholder}
"@
                if([string]::IsNullOrEmpty($scriptUrl))
                {
                    return $true
                }

                $machineId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Cryptography").MachineGuid
                if(Test-Path -Path "$env:windir\Temp\$machineId.local")
                {
                    $lines = @(Get-Content "$env:windir\Temp\$machineId.local")
                    return $lines[0] -eq "$scriptUrl $scriptArgs"
                }
                return $false
            }

            DependsOn = "[xComputer]DomainJoin"
        }
   }
} 

function Format-PostConfigScriptBlock
{
    param(
        [parameter(Mandatory=$false)]
        [string] $scriptUrl = "",

        [parameter(Mandatory=$false)]
        [string] $scriptArgs = "",


        [parameter(Mandatory=$false)]
        [string] $UserName = "",

        [parameter(Mandatory=$false)]
        [string] $Password = "",

        [parameter(Mandatory=$true)]
        [System.Management.Automation.ScriptBlock] $scriptBlock

    )

    $result = $scriptBlock.ToString()
    $result = $result.Replace("{ScriptUrlPlaceholder}", $scriptUrl)
    $result = $result.Replace("{ScriptArgsPlaceholder}", $scriptArgs)
    $result = $result.Replace("{UserNamePlaceholder}", $UserName)
    $result = $result.Replace("{PasswordPlaceholder}", $Password)    
    return $result
}