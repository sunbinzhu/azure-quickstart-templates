#
# xHpcPackInstall: DSC resource to install HPC Pack.
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePassword,

        # For HeadNode only
        [string] $ClusterName,

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )

    return $PSBoundParameters
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePassword,

        # For HeadNode only
        [string] $ClusterName = "",

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )

    $downloader = New-Object System.Net.WebClient
    if($SetupPkgPath -match "^http")
    {
        $setupPkgUrl = $SetupPkgPath
        $SetupPkgPath = Join-Path "$env:windir\Temp" $($setupPkgUrl -split '/')[-1]
        DownloadFile -Downloader $downloader -SourceUrl $setupPkgUrl -DestPath $SetupPkgPath
    }
    if($PfxFilePath -match "^http")
    {
        $pfxFileUrl = $PfxFilePath
        $PfxFilePath = Join-Path "$env:windir\Temp" $($pfxFileUrl -split '/')[-1]
        DownloadFile -Downloader $downloader -SourceUrl $pfxFileUrl -DestPath $PfxFilePath
    }

    $tgtdir = $SetupPkgPath.Substring(0, $SetupPkgPath.LastIndexOf('.'))
    if(Test-Path -Path $tgtdir -PathType Container)
    {
        $tgtdir = $tgtdir + '1'
    }
    [System.Reflection.Assembly]::LoadWithPartialName('System.IO.Compression.FileSystem') | Out-Null
    [System.IO.Compression.ZipFile]::ExtractToDirectory($SetupPkgPath, $tgtdir) | Out-Null
    if($NodeType -eq "HeadNode")
    {
        $setupArg = "-unattend -HeadNode -HeadNodeList:`"$HeadNodeList`" -ClusterName:$ClusterName -SSLPfxFilePath:`"$pfxFilePath`" -SSLPfxFilePassword:`"$PfxFilePassword`""
    }
    elseif($NodeType -eq "HeadNodePreReq")
    {
        $setupArg = "-unattend -HeadNodePreReq -SSLPfxFilePath:`"$pfxFilePath`" -SSLPfxFilePassword:`"$PfxFilePassword`""
    }
    else
    {
        $setupArg = "-unattend -${NodeType}:`"$HeadNodeList`" -SSLPfxFilePath:`"$pfxFilePath`" -SSLPfxFilePassword:`"$PfxFilePassword`""        
    }

    $retry = 0
    while($retry -lt 10)
    {
        TraceVerbose ("Installing HPC $NodeType")
        $p = Start-Process -FilePath "$tgtdir\setup.exe" -ArgumentList $setupArg -PassThru -Wait
        if($p.ExitCode -eq 0)
        {
            TraceVerbose ("Succeed to Install HPC $NodeType")
            break
        }
        TraceVerbose ("Failed to Install HPC $NodeType, return code is " + $p.ExitCode)
        Start-Sleep -Seconds 20
        $retry++
    }
    if($retry -eq 10)
    {
        throw "Failed to install $NodeType in $env:ComputerName"
    }
}

function Test-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)]
        [ValidateSet("HeadNode","ComputeNode", "BrokerNode", "WorkstationNode", "HeadNodePreReq")]
        [string] $NodeType,

        [parameter(Mandatory = $true)]
        [string] $HeadNodeList,

        [parameter(Mandatory = $true)]
        [string] $SetupPkgPath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePath,

        [parameter(Mandatory = $true)]
        [string] $PfxFilePassword,

        # For HeadNode only
        [string] $ClusterName,

        # For HeadNode only
        [string] $SQLServerInstance = ""
    )
    
    $clientGuid = "186B7E1A-6C30-46AB-AB83-4AE925377838"
    $serverGuid = "02985CCE-D7D5-40FF-9C81-6334523210F9"
    if(@("ComputeNode", "BrokerNode", "WorkstationNode") -contains $NodeType)
    {
        $serverProp = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ?{$_.UninstallString -and $_.UninstallString -match $serverGuid}
        return ($null -ne $serverProp)
    }
    else
    {
        $clientGuid = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | ?{$_.UninstallString -and $_.UninstallString -match $clientGuid}
        if($NodeType -eq "HeadNodePreReq")
        {
            return ($null -ne $clientGuid)        
        }
        else
        {
            $fabricSvc = Get-Service -Name 'fabricHostSvc' -ErrorAction SilentlyContinue
            return (($null -ne $fabricSvc) -and ($null -ne $clientGuid))
        }
    }
}

function DownloadFile
{
    param(
        [parameter(Mandatory = $false)]
        [System.Net.WebClient] $Downloader = $null,

        [parameter(Mandatory = $true)]
        [string] $SourceUrl,

        [parameter(Mandatory = $true)]
        [string] $DestPath
    )

    if($Downloader -eq $null)
    {
        $Downloader = New-Object System.Net.WebClient
    }

    $fileName = $($SourceUrl -split '/')[-1]
    if(Test-Path -Path $DestPath -PathType Container)
    {
        $DestPath = [IO.Path]::Combine($DestPath, $fileName)
    }

    $downloadRetry = 0
    while($true)
    {
        try
        {
            if(Test-Path -Path $DestPath)
            {
                Remove-Item -Path $DestPath -Force -Confirm:$false -ErrorAction SilentlyContinue
            }

            TraceVerbose "Downloading $SourceUrl to $DestPath(Retry=$downloadRetry)."
            $Downloader.DownloadFile($SourceUrl, $DestPath)
            TraceVerbose "Downloaded $SourceUrl to $DestPath."
            break
        }
        catch
        {
            if($downloadRetry -lt 10)
            {
                TraceVerbose ("Failed to download files, retry after 20 seconds:" + $_)
                Clear-DnsClientCache
                Start-Sleep -Seconds 20
                $downloadRetry++
            }
            else
            {
               throw "Failed to download files after 10 retries"
            }
        }
    }
}

function TraceVerbose
{
    param(
    [string] $Message
    )

    Write-Verbose "$(Get-Date -format yyyy-MM-dd_HH-mm-ss) $Message"
}

Export-ModuleMember -Function *-TargetResource
